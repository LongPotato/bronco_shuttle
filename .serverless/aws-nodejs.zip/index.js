var test = require('./handler.js');

test.fetchWaitingtimes();
